# My Portfolio

1. Create new GitHub repository called “username.github.io”, replacing username with your GitHub username.
2. Setup with GitHub Desktop
3. Go to portfolio-building-2 workshop, download the ZIP
4. Unzip and move files to the username.github.io repository locally
5. Make changes to make it your own portfolio, including styles, projects, etc.

-   Inspiration: https://github.com/emmabostian/developer-portfolios?tab=readme-ov-file

6. Commit to the main branch.
7. Go to username.github.io in ~2 minutes, site should be live
